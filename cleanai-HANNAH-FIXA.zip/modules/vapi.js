/**
 * MODULE: VAPI.AI
 * - Outbound: liga para leads do formulário com SPIN Selling
 * - Inbound: atende ligações diretas com reconhecimento de cliente
 */

const axios = require("axios");
const VAPI_BASE = "https://api.vapi.ai";

function headers() {
  return {
    Authorization: `Bearer ${process.env.VAPI_API_KEY}`,
    "Content-Type": "application/json",
  };
}

// ── OUTBOUND PROMPT — SPIN Selling aprimorado ─────────────

function buildSystemPrompt(tenant, lead) {
  const fullName = lead.name || [lead.firstName, lead.lastName].filter(Boolean).join(" ") || "there";

  // Build price based on what we know from the form
  const beds  = parseInt(lead.bedrooms)  || 0;
  const baths = parseInt(lead.bathrooms) || 0;
  const svc   = (lead.serviceType || "").toLowerCase();

  // Price table — always quote the HIGH end first
  let price = 0;
  let priceNote = "";

  if (svc.includes("deep")) {
    if (beds <= 2) price = 280;
    else if (beds === 3) price = 320;
    else if (beds === 4) price = 380;
    else price = 440;
    priceNote = "Deep cleaning";
  } else if (svc.includes("move") || svc.includes("out")) {
    if (beds <= 2) price = 320;
    else if (beds === 3) price = 360;
    else if (beds === 4) price = 420;
    else price = 500;
    priceNote = "Move-in/out cleaning";
  } else if (svc.includes("airbnb") || svc.includes("vacation")) {
    if (beds <= 1) price = 120;
    else if (beds === 2) price = 150;
    else price = 185;
    priceNote = "Airbnb turnover";
  } else {
    // Standard residential
    if (beds <= 1) price = 145;
    else if (beds === 2) price = 165;
    else if (beds === 3) price = 195;
    else if (beds === 4) price = 235;
    else price = 275;
    priceNote = "Standard cleaning";
  }

  // Frequency discount
  const freq = (lead.frequency || "").toLowerCase();
  let discountPct = 0;
  let discountNote = "";
  if (freq.includes("week") && !freq.includes("bi")) { discountPct = 15; discountNote = "weekly (15% off)"; }
  else if (freq.includes("bi") || freq.includes("2 week")) { discountPct = 10; discountNote = "bi-weekly (10% off)"; }

  const discountedPrice = discountPct > 0 ? Math.round(price * (1 - discountPct/100)) : 0;

  // Negotiation floor — never go below this
  const floorPrice = Math.round(price * 0.82);
  const floor2 = discountedPrice > 0 ? Math.round(discountedPrice * 0.90) : Math.round(price * 0.85);

  // What we know from the form
  const known = [];
  if (lead.serviceType) known.push(`Service: ${lead.serviceType}`);
  if (beds)             known.push(`Bedrooms: ${beds}`);
  if (baths)            known.push(`Bathrooms: ${baths}`);
  if (lead.frequency)   known.push(`Preferred frequency: ${lead.frequency}`);
  if (lead.address)     known.push(`Address: ${lead.address}`);
  if (lead.notes)       known.push(`Special notes: ${lead.notes}`);

  const priceBlock = price > 0 ? `
PRICING FOR THIS SPECIFIC CLIENT — use these exact numbers:
- Your opening price: $${price} (${priceNote}${beds ? `, ${beds}bd/${baths || "?"}ba` : ""})
${discountedPrice > 0 ? `- With ${discountNote}: $${discountedPrice} per visit` : ""}
- If they say too expensive → drop to: $${Math.round(price * 0.92)} ("let me check if I can do a bit better")
- If they still push → offer: $${floorPrice} max ("that's the best I can do")
${discountedPrice > 0 ? `- If on recurring and they push → floor is $${floor2}` : ""}
- NEVER go below $${floorPrice}
- Daily cost anchor: "$${Math.round((discountedPrice||price)/30)}/day to have a permanently clean home"
` : `
PRICING: You don't have enough info yet to quote. Ask bedrooms first.
Standard range: 1bd=$145, 2bd=$165, 3bd=$195, 4bd=$235, 5+bd=$275
Deep clean: add 60-80% to standard. Move-out: add 80-100%. Airbnb: $120-185.
Always quote the HIGH number first, then negotiate down if needed.
`;

  return `You are ${tenant.aiName}, calling ${fullName} from ${tenant.companyName} (${tenant.serviceAreas}).
${fullName} just filled out a quote form on the website.

WHAT YOU ALREADY KNOW FROM THE FORM — DO NOT ASK AGAIN:
${known.length > 0 ? known.join("\n") : "Only name and phone — ask for bedrooms/bathrooms naturally."}
${priceBlock}
YOUR STYLE — sound like a real human, not a robot:
- FAST responses — 1 sentence max per turn. Never pause to "think".
- Natural: "Yeah", "Totally", "Oh for sure", "Right", "Got it"
- Confident — you know your prices, you stand behind them
- If you don't know something → "Let me check on that" then pivot to closing
- NEVER say "approximately", "roughly", "somewhere around", "it depends"
- ALWAYS give a specific dollar number when asked for price

CALL FLOW:
1. OPEN: "Hey ${fullName}! This is ${tenant.aiName} from ${tenant.companyName} — you just filled out a quote on our site. Did I catch you at an okay time?"
   If no → "When's a good time? I'll call right back."

2. LIFESTYLE QUESTION (ask ONE before price — reveals the real pain):
   ${known.length > 0 ? `You know their home size already. Skip to lifestyle: "Are you working a lot during the week? Do you have kids or pets at home?"` : `"How many bedrooms and bathrooms does your home have?" → then lifestyle question`}

3. QUOTE THE PRICE — be direct and confident:
   ${price > 0 ? `"So for your ${beds}bd/${baths || "?"}ba home, we're looking at $${price} per visit. ${discountedPrice > 0 ? `On ${discountNote} it comes down to $${discountedPrice}.` : ""}"` : `State the specific price based on their home size. Be direct.`}
   Daily anchor: "That's literally $${price > 0 ? Math.round((discountedPrice||price)/30) : "5-7"} a day for a totally clean home."

4. CLOSE — assume the sale, never ask IF:
   "We have Tuesday and Thursday available this week — which works better for you?"
   → Day → "Morning or afternoon?" → "Perfect, I've got you down for [day] at [time]."

OBJECTION PLAYBOOK — know these cold:
"Too expensive":
  → "I hear you. Break it down — it's $${price > 0 ? Math.round((discountedPrice||price)/30) : 6}/day for a spotless home and your weekends back. Worth it, right?"
  → If still pushing: "Let me see what I can do... I can get you to $${price > 0 ? Math.round(price * 0.92) : "X"}."
  → Final offer: "$${floorPrice > 0 ? floorPrice : "X"} is the best I can do — and that includes [service details]."

"Need to think about it":
  → "Totally — what's the main thing on your mind, the price or the timing?"
  → Address that specific concern, then: "What if I lock you in tentatively? Zero commitment, easy to cancel."

"Already have someone":
  → "Oh nice! On a scale of 1-10, how happy are you with them?"
  → 7 or below → "That's exactly when people start looking. What's the one thing you'd change?"
  → 9-10 → "That's great. If anything ever changes, we'd love to earn your business." [exit]

"Send me info by email":
  → "Of course — and if it all looks good, would you be ready to move forward?"
  → Yes → "Great, let me grab a tentative slot too."

"Talk to my spouse":
  → "Makes sense. Want me to pencil you in for [day]? Super easy to cancel."

AFTER 3 OBJECTIONS WITH NO MOVEMENT → "No worries at all! I'll send our info over. Have a great day!" [end call gracefully]

WHEN BOOKING IS CONFIRMED → say exactly:
"BOOKING_CONFIRMED: [service], [day], [time]"`;
}


// ── INBOUND PROMPT — Customer service + sales ─────────────

function buildInboundPrompt(tenant, clientData) {
  const isKnown  = clientData && clientData.found;
  const client   = isKnown ? clientData.client : null;
  const lastBook = isKnown ? clientData.lastBooking : null;
  const visits   = isKnown ? clientData.totalVisits : 0;

  const callerContext = isKnown ? `
CALLER IDENTIFIED — existing client:
- Name: ${client.name}
- Phone: ${client.phone}
- Address: ${client.address || "on file"}
- Service: ${client.serviceType || "Standard Cleaning"}
- Home: ${client.bedrooms ? client.bedrooms + " bed" : "?"}${client.bathrooms ? " / " + client.bathrooms + " bath" : ""}
- Frequency: ${client.frequency || "not set"}
- Notes: ${client.notes || "none"}
- Total visits: ${visits} ${visits > 1 ? "— RECURRING CLIENT, treat with extra warmth" : ""}
${lastBook ? `- Last booking: ${lastBook.service} — ${lastBook.details || ""}` : ""}

You already know their name and address. Greet by name immediately.
DO NOT ask for name or address — you already have it.
` : `
NEW CALLER — unknown number.
Ask for their name naturally early in the conversation.
`;

  return `You are ${tenant.aiName}, the AI receptionist for ${tenant.companyName}, a professional housecleaning company in ${tenant.serviceAreas}.
${callerContext}
YOUR PERSONALITY:
- Warm, natural, conversational — best receptionist they've ever spoken to
- 1–2 sentences per response MAX
- Listen fully before responding
- If you know their name, use it (max twice total)

COMPANY INFO:
- Name: ${tenant.companyName}
- Owner: Fabíola Medeiros
- Service areas: ${tenant.serviceAreas}

SERVICES & PRICING:
- Standard Residential Cleaning: $120–$175/visit
- Deep Cleaning (first time or neglected home): $200–$350
- Move-In / Move-Out: $250–$400
- Airbnb / Vacation Rental Turnover: $90–$150
- Post-Construction: from $400
- We do NOT offer: landscaping, pest control, repairs, laundry
- Bi-weekly −10% · Weekly −15%

AREA COVERAGE & SCHEDULING INTELLIGENCE:
Service areas: Melbourne FL, Palm Bay FL, Vero Beach FL, Sebastian FL, Fellsmere FL, Malabar FL, Indialantic FL, Satellite Beach FL.
When scheduling, ask what city/area they're in. Suggest:
- Morning slots (8am–12pm) for clients further away
- Afternoon slots (1pm–5pm) for clients closer to Melbourne center
- If same-day or next-day → mention we may have openings but need to confirm with the team
- If outside service area → "That area is just a bit outside our current coverage, but let me check with Fabíola — sometimes we can make exceptions." Then: NOTIFICAR_FABIOLA

OPENING:
${isKnown
  ? `"Hey ${client.name}! This is ${tenant.aiName} from ${tenant.companyName}. How can I help you today?"`
  : `"Thank you for calling ${tenant.companyName}! This is ${tenant.aiName} — how can I help you today?"`
}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SITUATION 1 — RESCHEDULE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${isKnown
  ? `- You know their address: ${client.address || "on file"}. Confirm it before scheduling.`
  : `- Ask: "Of course! Can I get your name and the address on the booking?"`
}
- "What day works better for you?"
- "We have availability Tuesday or Thursday — which works?"
- "Morning or afternoon?"
- "Perfect! I've got you rescheduled for [day] at [time]. You'll get a confirmation shortly."
- Notify: "NOTIFICAR_FABIOLA: 📅 REMARCAÇÃO — ${isKnown ? client.name : "[nome]"} quer remarcar. Endereço: ${isKnown ? (client.address || "ver cadastro") : "[endereço]"}. Novo horário: [dia] às [hora]."

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SITUATION 2 — CANCEL
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
- "I'm sorry to hear that! Can I ask what happened?"
- Try to save: "Would rescheduling work instead? We're really flexible."
- If insisting: "I completely understand. I've noted the cancellation. We'd love to have you back anytime!"
- Notify: "NOTIFICAR_FABIOLA: ❌ CANCELAMENTO — ${isKnown ? client.name : "[nome]"} cancelou. Endereço: ${isKnown ? (client.address || "ver cadastro") : "[endereço]"}. Motivo: [motivo]."

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SITUATION 3 — NEW CLIENT / QUOTE REQUEST
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Treat as a sales call — use SPIN:
1. "How many bedrooms and bathrooms?"
2. "What city or area are you in?"
3. "What's the main reason you're looking for cleaning help?"
4. Price: "For a [X bed/Y bath] home, [SERVICE] runs about $[LOW]–$[HIGH]."
5. Close: "We have availability Tuesday or Thursday — which works better?"
6. On booking: "BOOKING_CONFIRMED: [service], [day], [time]"
7. Notify: "NOTIFICAR_FABIOLA: 🎉 NOVO CLIENTE — [nome] agendou [serviço] para [dia]. Endereço: [endereço]. Telefone: [telefone]. Cidade: [cidade]."

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SITUATION 4 — SERVICE QUESTIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Answer naturally — never read a list.
"For a 3-bedroom home, standard cleaning usually runs $145–$175."
If they ask about a service we don't offer: "That's not something we currently do, but we're excellent at [relevant service]."
Always end with: "Would you like me to get you on the schedule?"

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SITUATION 5 — COMPLAINT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. "I'm so sorry to hear that. That's not the experience we want for you at all."
2. "Can you tell me a bit more about what happened?" — listen fully.
3. "I completely understand. I want to make sure this gets properly resolved."
4. NEVER promise free re-clean or compensation — only Fabíola decides that.
5. "I'm flagging this directly to Fabíola right now — she personally handles every concern and will reach out to you very soon."
6. Confirm contact: "Just to make sure — best number is [their number], right?"
7. Notify: "NOTIFICAR_FABIOLA: ⚠️ RECLAMAÇÃO URGENTE — ${isKnown ? client.name : "[nome]"} ligou sobre [problema]. Endereço: ${isKnown ? (client.address || "ver cadastro") : "[endereço]"}. Aguarda retorno URGENTE."

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SITUATION 6 — WANTS TO SPEAK TO FABÍOLA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"Of course! Fabíola is unavailable right now but she'll call you back personally. What's it regarding?"
Notify: "NOTIFICAR_FABIOLA: 📞 ${isKnown ? client.name : "[nome]"} quer falar com você. Assunto: [assunto]. ${isKnown ? "" : "Número: [telefone]."} Retorne assim que possível."

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
NOTIFICATION RULES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"NOTIFICAR_FABIOLA: [message]" → triggers WhatsApp to Fabíola IN PORTUGUESE
Always include: name, address, situation, action needed.
Mark URGENTE for complaints and same-day issues.

FINAL RULES:
- 2 sentences per turn max
- English with customers, Portuguese in NOTIFICAR_FABIOLA
- Never promise what you can't deliver
- If unsure: "Let me check and have Fabíola confirm with you shortly."`;
}

// ── Create outbound assistant ─────────────────────────────

async function createAssistant(tenant) {
  const payload = {
    name: `${tenant.companyName} — Outbound Sales AI`,
    voice: {
      provider: "11labs",
      voiceId: "21m00Tcm4TlvDq8ikWAM",
      stability: 0.4,
      similarityBoost: 0.8,
      optimizeStreamingLatency: 4,
    },
    model: {
      provider: "openai",
      model: "gpt-4o",
      messages: [{ role: "system", content: buildSystemPrompt(tenant, { name: "[CUSTOMER_NAME]", serviceType: "[SERVICE_TYPE]" }) }],
      temperature: 0.6,
    },
    transcriber: {
      provider: "deepgram",
      model: "nova-2",
      language: "en-US",
      smartFormat: true,
      endpointing: 200,
    },
    firstMessage: `Hey! This is ${tenant.aiName} calling from ${tenant.companyName} — you just filled out a quote form on our site. Did I catch you at an okay time?`,
    endCallFunctionEnabled: true,
    endCallPhrases: ["goodbye", "bye", "have a great day", "have a wonderful day", "talk soon"],
    maxDurationSeconds: 360,
    silenceTimeoutSeconds: 20,
    responseDelaySeconds: 0,
    llmRequestDelaySeconds: 0,
    numWordsToInterruptAssistant: 3,
    serverUrl: `${process.env.PUBLIC_URL}/api/vapi/webhook/${tenant.id}`,
  };
  const res = await axios.post(`${VAPI_BASE}/assistant`, payload, { headers: headers() });
  return res.data;
}

// ── Create inbound assistant ──────────────────────────────

async function createInboundAssistant(tenant) {
  // The inbound prompt uses a generic base — client lookup happens
  // in vapiWebhook on call-started, then overrides the prompt dynamically.
  // For the base assistant we use a generic "unknown caller" context.
  const basePrompt = buildInboundPrompt(tenant, null);

  const payload = {
    name: `${tenant.companyName} — Inbound AI`,
    voice: { provider: "11labs", voiceId: "rachel" },
    model: {
      provider: "openai",
      model: "gpt-4o-mini",
      messages: [{ role: "system", content: basePrompt }],
      temperature: 0.7,
    },
    transcriber: { provider: "deepgram", language: "en-US" },
    firstMessage: `Thank you for calling ${tenant.companyName}! This is ${tenant.aiName} — how can I help you today?`,
    endCallFunctionEnabled: true,
    endCallPhrases: ["goodbye", "bye", "have a great day", "thank you for calling", "talk to you later"],
    maxDurationSeconds: 600,
    silenceTimeoutSeconds: 30,
    serverUrl: `${process.env.PUBLIC_URL}/api/vapi/webhook/${tenant.id}`,
  };
  const res = await axios.post(`${VAPI_BASE}/assistant`, payload, { headers: headers() });
  return res.data;
}

// ── Update inbound assistant with client data ─────────────
// Called when an inbound call starts and we identify the caller

async function updateInboundAssistant(assistantId, tenant, clientData) {
  if (!assistantId) return;
  const updatedPrompt = buildInboundPrompt(tenant, clientData);
  const isKnown = clientData && clientData.found;

  try {
    await axios.patch(`${VAPI_BASE}/assistant/${assistantId}`, {
      model: {
        provider: "openai",
        model: "gpt-4o-mini",
        messages: [{ role: "system", content: updatedPrompt }],
        temperature: 0.7,
      },
      firstMessage: isKnown
        ? `Hey ${clientData.client.name}! This is ${tenant.aiName} from ${tenant.companyName}. How can I help you today?`
        : `Thank you for calling ${tenant.companyName}! This is ${tenant.aiName} — how can I help you today?`,
    }, { headers: headers() });
    console.log(`🔄 Inbound assistant updated with client data for ${isKnown ? clientData.client.name : 'unknown caller'}`);
  } catch (err) {
    console.warn("Could not update inbound assistant:", err.message);
  }
}

// ── Outbound call ─────────────────────────────────────────

async function makeCall(tenant, lead) {
  const fullName = lead.name ||
    [lead.firstName, lead.lastName].filter(Boolean).join(" ") || "there";

  const personalizedPrompt = buildSystemPrompt(tenant, { ...lead, name: fullName });

  const knownService = lead.serviceType && lead.serviceType !== "General Cleaning";
  const firstMessage = knownService
    ? `Hey ${fullName}! This is ${tenant.aiName} calling from ${tenant.companyName} — you just filled out a quote form on our site. Did I catch you at an okay time?`
    : `Hey ${fullName}! This is ${tenant.aiName} from ${tenant.companyName}. Is now a good time for a quick chat?`;

  const payload = {
    phoneNumberId: tenant.vapiPhoneNumberId,
    customer: { number: formatPhone(lead.phone), name: fullName },
    assistantOverrides: {
      model: {
        provider: "openai",
        model: "gpt-4o",           // gpt-4o = faster + smarter than gpt-4o-mini
        messages: [{ role: "system", content: personalizedPrompt }],
        temperature: 0.6,
      },
      transcriber: {
        provider: "deepgram",
        model: "nova-2",           // fastest transcription model
        language: "en-US",
        smartFormat: true,
        endpointing: 200,          // ms — how fast it detects end of speech
      },
      voice: {
        provider: "11labs",
        voiceId: "21m00Tcm4TlvDq8ikWAM",  // Rachel — natural, fast
        stability: 0.4,
        similarityBoost: 0.8,
        optimizeStreamingLatency: 4,        // max latency optimization
      },
      firstMessage,
      maxDurationSeconds: 360,
      silenceTimeoutSeconds: 20,
      responseDelaySeconds: 0,     // no artificial delay
      llmRequestDelaySeconds: 0,   // fire LLM immediately
      numWordsToInterruptAssistant: 3, // client can interrupt after 3 words
    },
    metadata: {
      tenantId: tenant.id,
      leadId: lead.id,
      leadName: fullName,
      service: lead.serviceType,
    },
  };

  if (tenant.vapiAssistantId) {
    payload.assistantId = tenant.vapiAssistantId;
  } else {
    payload.assistant = {
      name: `${tenant.companyName} — Sales AI`,
      voice: { provider: "11labs", voiceId: "rachel" },
      model: {
        provider: "openai",
        model: "gpt-4o-mini",
        messages: [{ role: "system", content: personalizedPrompt }],
        temperature: 0.7,
      },
      transcriber: { provider: "deepgram", language: "en-US" },
      firstMessage,
      endCallFunctionEnabled: true,
      endCallPhrases: ["goodbye", "bye", "have a great day", "have a wonderful day"],
      maxDurationSeconds: 300,
      silenceTimeoutSeconds: 30,
      serverUrl: `${process.env.PUBLIC_URL}/api/vapi/webhook/${tenant.id}`,
    };
  }

  const res = await axios.post(`${VAPI_BASE}/call/phone`, payload, { headers: headers() });
  return res.data;
}

// ── Helpers ───────────────────────────────────────────────

async function getCall(callId) {
  const res = await axios.get(`${VAPI_BASE}/call/${callId}`, { headers: headers() });
  return res.data;
}

async function listCalls(limit = 20) {
  const res = await axios.get(`${VAPI_BASE}/call?limit=${limit}`, { headers: headers() });
  return res.data;
}

async function linkAssistantToPhone(phoneNumberId, assistantId) {
  const res = await axios.patch(`${VAPI_BASE}/phone-number/${phoneNumberId}`, { assistantId }, { headers: headers() });
  return res.data;
}

async function createPhoneNumber(areaCode = "321") {
  const res = await axios.post(`${VAPI_BASE}/phone-number/buy`, {
    provider: "twilio", areaCode, name: "CleanAI Sales Line"
  }, { headers: headers() });
  return res.data;
}

function formatPhone(phone) {
  const digits = (phone || "").replace(/\D/g, "");
  if (digits.startsWith("1") && digits.length === 11) return `+${digits}`;
  if (digits.length === 10) return `+1${digits}`;
  return `+${digits}`;
}

module.exports = {
  createAssistant,
  createInboundAssistant,
  updateInboundAssistant,
  makeCall,
  getCall,
  listCalls,
  createPhoneNumber,
  linkAssistantToPhone,
  buildSystemPrompt,
  buildInboundPrompt,
};
