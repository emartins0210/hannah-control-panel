/**
 * TENANT DATABASE
 * Armazena os dados de cada empresa cliente do SaaS.
 * Em produção, substitua por PostgreSQL ou MongoDB.
 * Por agora: arquivo JSON simples (funciona perfeitamente para começar).
 */

const fs   = require("fs");
const path = require("path");

const DB_FILE = path.join(__dirname, "../config/tenants.json");

// Garante que o arquivo existe
if (!fs.existsSync(DB_FILE)) {
  fs.writeFileSync(DB_FILE, JSON.stringify({ tenants: [] }, null, 2));
}

function load() {
  return JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
}

function save(data) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

// ── CRUD ─────────────────────────────────────────────────

function getAll() {
  return load().tenants;
}

function getById(id) {
  return load().tenants.find(t => t.id === id) || null;
}

function getByWebhookKey(key) {
  return load().tenants.find(t => t.webhookKey === key) || null;
}

function create(tenant) {
  const db = load();
  db.tenants.push(tenant);
  save(db);
  return tenant;
}

function update(id, fields) {
  const db = load();
  const idx = db.tenants.findIndex(t => t.id === id);
  if (idx === -1) return null;
  db.tenants[idx] = { ...db.tenants[idx], ...fields, updatedAt: new Date().toISOString() };
  save(db);
  return db.tenants[idx];
}

function remove(id) {
  const db = load();
  db.tenants = db.tenants.filter(t => t.id !== id);
  save(db);
}

module.exports = { getAll, getById, getByWebhookKey, create, update, remove };
