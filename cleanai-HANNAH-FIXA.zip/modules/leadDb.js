/**
 * LEAD DATABASE
 * Armazena leads por tenant.
 * Em produção: PostgreSQL. Por agora: JSON.
 */

const fs   = require("fs");
const path = require("path");

const DB_FILE = path.join(__dirname, "../config/leads.json");

if (!fs.existsSync(DB_FILE)) {
  fs.writeFileSync(DB_FILE, JSON.stringify({ leads: [] }, null, 2));
}

function load() {
  return JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
}

function save(data) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

function getByTenant(tenantId) {
  return load().leads.filter(l => l.tenantId === tenantId);
}

function getById(id) {
  return load().leads.find(l => l.id === id) || null;
}

// Busca cliente pelo telefone — normaliza formato antes de comparar
function getByPhone(tenantId, phone) {
  const digits = phone.replace(/\D/g, "");
  const leads  = load().leads.filter(l => l.tenantId === tenantId);
  // Ordena por mais recente primeiro
  leads.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  return leads.find(l => {
    const d = (l.phone || "").replace(/\D/g, "");
    return d === digits || d.endsWith(digits.slice(-10)) || digits.endsWith(d.slice(-10));
  }) || null;
}

// Retorna histórico completo do cliente (todas as limpezas)
function getHistoryByPhone(tenantId, phone) {
  const digits = phone.replace(/\D/g, "");
  const leads  = load().leads.filter(l => l.tenantId === tenantId);
  return leads
    .filter(l => {
      const d = (l.phone || "").replace(/\D/g, "");
      return d === digits || d.endsWith(digits.slice(-10)) || digits.endsWith(d.slice(-10));
    })
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

function create(lead) {
  const db = load();
  db.leads.push(lead);
  save(db);
  return lead;
}

function update(id, fields) {
  const db = load();
  const idx = db.leads.findIndex(l => l.id === id);
  if (idx === -1) return null;
  db.leads[idx] = { ...db.leads[idx], ...fields, updatedAt: new Date().toISOString() };
  save(db);
  return db.leads[idx];
}

module.exports = { getByTenant, getById, getByPhone, getHistoryByPhone, create, update };
