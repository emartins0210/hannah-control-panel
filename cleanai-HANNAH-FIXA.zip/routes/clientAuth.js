/**
 * ROUTE: CLIENT AUTH
 * Login separado para cada empresa cliente.
 * Cada empresa vê APENAS seus próprios leads.
 *
 * POST /api/client/login  → autentica com email + senha
 * GET  /api/client/leads  → retorna leads da empresa logada
 */

const express  = require("express");
const router   = express.Router();
const tenantDb = require("../modules/tenantDb");
const leadDb   = require("../modules/leadDb");

// ── Simple token: base64 do tenantId + timestamp ──────────
function generateToken(tenantId) {
  const payload = `${tenantId}:${Date.now()}`;
  return Buffer.from(payload).toString("base64");
}

function verifyToken(token) {
  try {
    const decoded = Buffer.from(token, "base64").toString("utf8");
    const [tenantId] = decoded.split(":");
    return tenantId;
  } catch {
    return null;
  }
}

// ── Auth middleware for client routes ─────────────────────
function clientAuth(req, res, next) {
  const auth  = req.headers["authorization"] || "";
  const token = auth.replace("Bearer ", "").trim();
  if (!token) return res.status(401).json({ error: "Unauthorized" });

  const tenantId = verifyToken(token);
  if (!tenantId)  return res.status(401).json({ error: "Invalid token" });

  const tenant = tenantDb.getById(tenantId);
  if (!tenant)    return res.status(401).json({ error: "Company not found" });
  if (!tenant.active) return res.status(403).json({ error: "Account inactive" });

  req.tenant = tenant;
  next();
}

// ── POST /api/client/login ────────────────────────────────
router.post("/login", (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: "Email and password are required" });
  }

  // Find tenant by email
  const tenants = tenantDb.getAll();
  const tenant  = tenants.find(t =>
    t.ownerEmail && t.ownerEmail.toLowerCase() === email.toLowerCase()
  );

  if (!tenant) {
    return res.status(401).json({ error: "Email or password incorrect" });
  }

  // Check password (stored as clientPassword on the tenant)
  if (!tenant.clientPassword || tenant.clientPassword !== password) {
    return res.status(401).json({ error: "Email or password incorrect" });
  }

  if (!tenant.active) {
    return res.status(403).json({ error: "Your account is inactive. Contact support." });
  }

  const token = generateToken(tenant.id);

  // Return tenant info (safe fields only — no API keys)
  res.json({
    success: true,
    token,
    tenant: {
      id:          tenant.id,
      companyName: tenant.companyName,
      ownerName:   tenant.ownerName,
      ownerEmail:  tenant.ownerEmail,
      serviceAreas: tenant.serviceAreas,
      aiName:      tenant.aiName,
    },
  });
});

// ── GET /api/client/leads ─────────────────────────────────
router.get("/leads", clientAuth, (req, res) => {
  const leads = leadDb.getByTenant(req.tenant.id);
  const sorted = leads.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json({ leads: sorted, count: sorted.length });
});

// ── GET /api/client/stats ─────────────────────────────────
router.get("/stats", clientAuth, (req, res) => {
  const leads  = leadDb.getByTenant(req.tenant.id);
  const booked = leads.filter(l => l.status === "booked" || l.outcome === "booked");
  const called = leads.filter(l => l.callId);

  res.json({
    totalLeads:     leads.length,
    called:         called.length,
    booked:         booked.length,
    conversionRate: leads.length > 0
      ? ((booked.length / leads.length) * 100).toFixed(1) + "%"
      : "0%",
  });
});

module.exports = router;
