/**
 * CLEANAI SAAS — SETUP AUTOMÁTICO
 * 
 * Executa após o deploy no Railway para configurar tudo automaticamente:
 * 1. Cria o tenant da Lopes Cleaning se não existir
 * 2. Cria o assistente Vapi outbound
 * 3. Cria o assistente Vapi inbound e vincula ao número
 * 4. Exibe resumo completo do sistema
 * 
 * Como usar:
 *   node setup.js
 */

require("dotenv").config();
const { v4: uuidv4 } = require("uuid");
const tenantDb = require("./modules/tenantDb");
const vapi     = require("./modules/vapi");

const LOPES = {
  companyName:       "Lopes Cleaning Services",
  ownerName:         "Fabíola Medeiros",
  ownerEmail:        "lopesservicescleaning@gmail.com",
  aiName:            "Hannah",
  serviceAreas:      "Melbourne FL, Palm Bay FL, Vero Beach FL, Sebastian FL, Satellite Beach FL, Indialantic FL",
  companyPhone:      "(321) 392-7880",
  reviewLink:        process.env.COMPANY_REVIEW_LINK || "",
  vapiPhoneNumberId: process.env.VAPI_PHONE_NUMBER_ID || "",
  plan:              "starter",
};

async function run() {
  console.log("\n╔══════════════════════════════════════╗");
  console.log("║   CleanAI SaaS — Auto Setup          ║");
  console.log("╚══════════════════════════════════════╝\n");

  // 1. Check env vars
  const required = ["VAPI_API_KEY", "ADMIN_SECRET", "PUBLIC_URL"];
  const missing  = required.filter(k => !process.env[k]);
  if (missing.length > 0) {
    console.error("❌ Missing required environment variables:");
    missing.forEach(k => console.error(`   - ${k}`));
    console.error("\nAdd them in Railway → Variables and run setup.js again.");
    process.exit(1);
  }
  console.log("✅ Environment variables OK\n");

  // 2. Find or create Lopes tenant
  let tenant = tenantDb.getAll().find(t => t.ownerEmail === LOPES.ownerEmail);

  if (tenant) {
    console.log(`✅ Tenant found: ${tenant.companyName} (${tenant.id})`);
  } else {
    tenant = tenantDb.create({
      id:         uuidv4(),
      webhookKey: uuidv4(),
      ...LOPES,
      services:           defaultServices(),
      vapiAssistantId:    "",
      vapiInboundAssistantId: "",
      clientPassword:     "LopesClean#2026!",
      active:             true,
      createdAt:          new Date().toISOString(),
      updatedAt:          new Date().toISOString(),
    });
    console.log(`✅ Tenant created: ${tenant.companyName} (${tenant.id})`);
  }

  const webhookUrl = `${process.env.PUBLIC_URL}/api/webhook/${tenant.webhookKey}`;
  const vapiWebhookUrl = `${process.env.PUBLIC_URL}/api/vapi/webhook/${tenant.id}`;

  // 3. Setup outbound assistant
  if (!tenant.vapiAssistantId && process.env.VAPI_PHONE_NUMBER_ID) {
    console.log("\n🤖 Creating outbound assistant...");
    try {
      const updatedTenant = { ...tenant, vapiPhoneNumberId: process.env.VAPI_PHONE_NUMBER_ID };
      const assistant = await vapi.createAssistant(updatedTenant);
      const assistantId = assistant.id || assistant.assistantId;
      tenant = tenantDb.update(tenant.id, {
        vapiAssistantId:   assistantId,
        vapiPhoneNumberId: process.env.VAPI_PHONE_NUMBER_ID,
      });
      console.log(`✅ Outbound assistant created: ${assistantId}`);

      // Link to phone number
      await vapi.linkAssistantToPhone(process.env.VAPI_PHONE_NUMBER_ID, assistantId);
      console.log("✅ Outbound assistant linked to phone number");
    } catch (err) {
      console.warn("⚠️  Could not create outbound assistant:", err.message);
      console.warn("   Run manually: Admin Panel → Companies → Setup Vapi");
    }
  } else if (tenant.vapiAssistantId) {
    console.log(`✅ Outbound assistant already configured: ${tenant.vapiAssistantId}`);
  } else {
    console.warn("⚠️  VAPI_PHONE_NUMBER_ID not set — skipping outbound assistant");
    console.warn("   Add VAPI_PHONE_NUMBER_ID to Railway Variables and re-run");
  }

  // 4. Setup inbound assistant
  if (!tenant.vapiInboundAssistantId && process.env.VAPI_PHONE_NUMBER_ID) {
    console.log("\n📞 Creating inbound assistant...");
    try {
      const currentTenant = tenantDb.getById(tenant.id);
      const inbound = await vapi.createInboundAssistant(currentTenant);
      const inboundId = inbound.id || inbound.assistantId;
      tenant = tenantDb.update(tenant.id, { vapiInboundAssistantId: inboundId });
      await vapi.linkAssistantToPhone(process.env.VAPI_PHONE_NUMBER_ID, inboundId);
      console.log(`✅ Inbound assistant created: ${inboundId}`);
      console.log("✅ Inbound assistant linked — Hannah will now answer all calls");
    } catch (err) {
      console.warn("⚠️  Could not create inbound assistant:", err.message);
      console.warn("   Run manually: Admin Panel → Companies → Inbound");
    }
  } else if (tenant.vapiInboundAssistantId) {
    console.log(`✅ Inbound assistant already configured: ${tenant.vapiInboundAssistantId}`);
  }

  // 5. Summary
  const t = tenantDb.getById(tenant.id);
  console.log("\n╔══════════════════════════════════════════════════════════╗");
  console.log("║              SETUP COMPLETE — SUMMARY                   ║");
  console.log("╠══════════════════════════════════════════════════════════╣");
  console.log(`║  Company:        ${pad(t.companyName, 38)}║`);
  console.log(`║  Tenant ID:      ${pad(t.id, 38)}║`);
  console.log(`║  Webhook Key:    ${pad(t.webhookKey, 38)}║`);
  console.log("╠══════════════════════════════════════════════════════════╣");
  console.log(`║  Outbound Asst:  ${pad(t.vapiAssistantId || "NOT SET", 38)}║`);
  console.log(`║  Inbound Asst:   ${pad(t.vapiInboundAssistantId || "NOT SET", 38)}║`);
  console.log(`║  Phone Number:   ${pad(t.vapiPhoneNumberId || "NOT SET", 38)}║`);
  console.log("╠══════════════════════════════════════════════════════════╣");
  console.log("║  URLS:                                                   ║");
  console.log(`║  Webhook:   ${pad(webhookUrl.slice(0,43), 44)}║`);
  console.log(`║  Vapi Hook: ${pad(vapiWebhookUrl.slice(0,43), 44)}║`);
  console.log("╠══════════════════════════════════════════════════════════╣");
  console.log("║  CLIENT PORTAL:                                          ║");
  console.log(`║  URL:     ${pad((process.env.PUBLIC_URL || "") + "/client", 46)}║`);
  console.log(`║  Email:   ${pad(t.ownerEmail, 46)}║`);
  console.log(`║  Password: LopesClean#2026!                              ║`);
  console.log("╠══════════════════════════════════════════════════════════╣");
  console.log("║  NEXT STEP — Configure Vapi webhook:                     ║");
  console.log("║  dashboard.vapi.ai → Assistant → Advanced → Server URL  ║");
  console.log(`║  ${pad(vapiWebhookUrl.slice(0,55), 55)}║`);
  console.log("╚══════════════════════════════════════════════════════════╝\n");
}

function pad(str, len) {
  str = str || "";
  return str.length > len ? str.slice(0, len) : str + " ".repeat(len - str.length);
}

function defaultServices() {
  return [
    { name: "Standard Residential Cleaning", price: "$120–$175/visit" },
    { name: "Deep Cleaning",                 price: "$200–$350/visit" },
    { name: "Move-In / Move-Out Cleaning",   price: "$250–$400"       },
    { name: "Airbnb Turnover",               price: "$90–$150/visit"  },
    { name: "Post-Construction Cleaning",    price: "From $400"       },
  ];
}

run().catch(err => {
  console.error("\n❌ Setup failed:", err.message);
  process.exit(1);
});
